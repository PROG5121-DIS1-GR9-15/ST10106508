/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;
/// MY imports are here//
import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * @author ntuzuma njabulo
 */
public class Task {
    // Variable Declaration//
    
  String task;
 String ab;
 String ef;
 int cd;
 String gh;
 String ij;
 String op;
 int l;
 
 // Get AND Setters are done here//
 public void setab(String ab){
     this.ab = ab;  
 }
 public String getab(){
     return ab;
}
 public void setef(String ef){
     this.ef= ef;  
 }
 public String getef(){
     return ef;
}
  public void setcd(int cd){
     this.cd = cd;  
 }
 public int getcd(){
     return cd;
}
  public void setop(String op){
     this.op = op;  
 }
 public String getop(){
     return op;
}
  public void setij(String ij){
     this.ij = ij;  
 }
 public String getij(){
     return ij;
}
 public void setgh(String gh){
     this.gh = gh;  
 }
 public String getgh(){
     return gh;
}
  public void setl(int l){
     this.l = l;  
 }
 public int getl(){
     return l;
}
  
  
  //Methods are done here//
    
public static boolean checkTaskDescription(String ef){
       boolean read = false;
     for(int j=0; j<ef.length(); j++){   
       if(ef.charAt(j)<=50){
           read = true;
          
     }
     }
     if(read== true && read){
         System.out.println("Task successfully captured");
     }else{
         System.out.println("Please enter a task description of less than 50 characters");
     }
     return true; 
    
}
 public static void createTaskID(String xx){
   Random get = new Random();

 int x = get.nextInt(99)+10;   
 }
 public static void printTaskDetails(String ab,int cd,String ef,String gh,  String ij, String op){
 // Task2 cpj = new Task2();
  //Task lk = new Task();
  String result;
  result = JOptionPane.showInputDialog("Hi  1st employee ,your name is ?" );
  
  JOptionPane.showMessageDialog(null,result +' '+ "Task Name:" + ab + "\n" +"Task Number:" + cd + "\n" + "Task Description:" + ef+ "\n" + "Developer Details:" + gh +
          "\n" + "Task Duration:" + ij+ "\n" + "Task Status:" + op);
 }
 
 public static void returnTotalhours(String ij){
     
 for(int j=0; j<ij.length(); j++){
     System.out.println("Task duration" + j++);
 }
 }
}
