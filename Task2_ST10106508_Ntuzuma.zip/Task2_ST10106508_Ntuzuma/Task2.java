/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package task2;
/// My Imports are here///

import java.util.Random;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import java.util.*;
import java.util.Date;

public class Task2 {
int choice;

    public static void main(String[] args) {
        // My Whole Code is Done Here including Scanners and methods///
   Scanner read = new Scanner(System.in);
  Task cpj = new Task();
  
      JFrame show = new JFrame();
      String found ="Y";
       Random get = new Random();
      int x = get.nextInt(99)+10;
//JOptionPane starts here///
   do{
    int choice = Integer.parseInt(JOptionPane.showInputDialog(show, "WELCOME TO EASYKANBAN" + "\n" +"Choose one of the follwoing features from the menu given below" + "\n" +
            "Option1) Add Task" +"\n"+
            "Option2)Show Report" + "\n" +
            "Option3) Quit")); 
     
   
   if(choice == 1){
       System.out.println("Hi,..Please Enter the number of tasks you wish to do!");
       String task = read.next();
       if(task ==task){
          
      System.out.println("Enter Task Name:");
     // String ab = read.next();
      String ab = read.next();
      cpj.setab(ab);
      //cpj.getab();
      System.out.println("Enter Task Number:");
      int cd = read.nextInt();
      
      System.out.println("Enter Task Description:");
      String ef = read.next();
      cpj.setef(ef);
 
      checkTaskDescription(cpj.getef());
   
  
      
      System.out.println("Enter Developer Details:");
      String gh = read.next();
      cpj.setgh(gh);
    
      
      System.out.println("Enter Task Duration:");
      String ij = read.next();
      cpj.setij(ij);
  
 
 
     
     System.out.println("Task ID:" + get.nextInt(99)+10 + "\n");
      int l = get.nextInt(99)+10;
      cpj.setl(l);
      
     System.out.println("Enter Task Status:");
     String op = read.next();
     cpj.setop(op);
     printTaskDetails(cpj.getab(),cpj.getcd(),cpj.getef(),cpj.getgh(), cpj.getij(),cpj.getl(),cpj.getop());
     returnTotalhours(cpj.getij());
     
       }    
   }else if(choice == 2){
       System.out.println("Coming Soon.......!");
       
   }else if(choice == 3){
       System.exit(choice);
   }
   
 //A JOptionPnae to loop If user wants to re enter details//
   
   found = JOptionPane.showInputDialog(show,"Would you like to exit the application ? Enter (Y) continue.");

     }while(found.equals("Y"));

      }
    ///My methods are pasted here///
    
    public static void printTaskDetails(String ab,int cd,String ef,String gh,String ij,int l, String op){
 
  
   Task cpj = new Task();

  String result;
  result = JOptionPane.showInputDialog("Click ok to view TaskDetails " + "\n");
  
  JOptionPane.showMessageDialog(null,' '+ "Task Name:" +""+ ab + "\n" +"Task Number:" +""+ cd + "\n" + "Task Description:" +""+ef+ "\n" + "Developer Details:"+""+ gh +
          "\n" + "Task Duration:"+""+ ij + "\n +" + "Task ID:"+""+ l + "\n" + "Task Status:"+""+ op);
 }
    public static boolean checkTaskDescription(String ef){
         Scanner input = new Scanner(System.in);
       boolean read = false;
     for(int j=0; j<ef.length(); j++){   
       if(ef.charAt(j)>32 && ef.charAt(j)<50){
           read = true;
          
     }
     }
     if(read== true && read){
        System.out.println("Task successfully captured");
     }else{
         System.out.println("Please enter a task description of less than 10 characters");
         System.out.println("Enter Task Description:");
         String in = input.next();
     }
     return true; 
    
 }
public static void returnTotalhours(String ij){
     
 for(int j=0; j<ij.length(); j++){
     System.out.println("Task duration" +"" + j++);
 }
 }
}


    
    


